const devices = {
    "device_001": "SECRET_KEY"
};

function isValidDevice(id, key) {
    return devices[id] === key;
}

module.exports = { isValidDevice };
