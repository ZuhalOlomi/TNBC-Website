const pool = require("./index");

async function saveEmg({ deviceId, value, timestamp }) {
    await pool.query(
        "INSERT INTO emg_data (device_id, value, timestamp) VALUES ($1,$2,$3)",
        [deviceId, value, timestamp]
    );
}

module.exports = { saveEmg };
