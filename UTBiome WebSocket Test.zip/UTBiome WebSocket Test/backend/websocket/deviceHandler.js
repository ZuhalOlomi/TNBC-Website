const { isValidDevice } = require("../auth/deviceAuth");
const { saveEmg } = require("../db/emgModel");
const { broadcastToSubscribers } = require("./clientHandler");

function handleDeviceMessage(ws, data) {
    if (!isValidDevice(data.deviceId, data.apiKey)) return;

    saveEmg(data);
    broadcastToSubscribers(data);
}

module.exports = { handleDeviceMessage };