const clients = new Map(); // ws -> deviceId

function handleClientMessage(ws, msg) {
    if (msg.subscribe) {
        clients.set(ws, msg.subscribe);
    }
}

function broadcastToSubscribers(data) {
    clients.forEach((deviceId, ws) => {
        if (deviceId === data.deviceId && ws.readyState === 1) {
            ws.send(JSON.stringify(data));
        }
    });
}

module.exports = { handleClientMessage, broadcastToSubscribers };