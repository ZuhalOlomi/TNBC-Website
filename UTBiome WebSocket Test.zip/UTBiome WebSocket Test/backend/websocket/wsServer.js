const WebSocket = require("ws");
const { handleDeviceMessage } = require("./deviceHandler");
const { handleClientMessage } = require("./clientHandler");

function initWebSocket(server) {
    const wss = new WebSocket.Server({ server });

    wss.on("connection", (ws) => {
        ws.on("message", (msg) => {
            const data = JSON.parse(msg);

            if (data.deviceId) {
                handleDeviceMessage(ws, data);
            } else {
                handleClientMessage(ws, data);
            }
        });
    });
}

module.exports = { initWebSocket };