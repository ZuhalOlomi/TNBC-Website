const express = require("express");
const { initWebSocket } = require("./ws/wsServer");

const app = express();
const server = app.listen(3000, () => {
    console.log("Server running on port 3000");
});

initWebSocket(server);