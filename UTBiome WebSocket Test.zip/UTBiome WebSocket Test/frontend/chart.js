function updateChart(value) {
    // push value into chart dataset
}
