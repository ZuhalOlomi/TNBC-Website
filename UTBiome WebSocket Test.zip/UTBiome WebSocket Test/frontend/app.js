const socket = new WebSocket("wss://your-server.com");

socket.onopen = () => {
    socket.send(JSON.stringify({ subscribe: "device_001" }));
};

socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    updateChart(data.value);
};
